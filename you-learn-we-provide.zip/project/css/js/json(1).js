function loadJSON() {
        var data_file = "courses.json";
        var http_request = new XMLHttpRequest();

      http_request.onreadystatechange = function() {

           if (http_request.readyState == 4  ) {
             if (http_request.status == 200) {
               // Javascript function JSON.parse to parse JSON data
               var jsonObj = JSON.parse(http_request.responseText);

               // jsonObj variable now contains the data structure and can
               // be accessed as jsonObj.name and jsonObj.country.
               document.getElementById("Name").innerHTML = jsonObj.id;
               document.getElementById("Album").innerHTML = jsonObj.name;
             }
           }
        }

        http_request.open("GET", data_file, true);
        http_request.send();
}